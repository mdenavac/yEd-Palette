yed-eip
=======

yEd palette of nodes for Enterprise integration patterns.

Import the EIP.graphml file into your palette: right click > Import Section.

Images from http://camel.apache.org/enterprise-integration-patterns.html
